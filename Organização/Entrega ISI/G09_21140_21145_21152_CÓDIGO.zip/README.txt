Entrega Final de Integração de Sistemas de Informação

Alunos: Pedro Simões 	  (21140)
	  Gonçalo Cunha 	  (21145)
        João Apresentação (21152)
Professor: Óscar Ribeiro

Funcionamento da aplicação: (de forma a testar requests)
- Tendo em conta que a base de dados é local, será necessário ligar a mesma na máquina
- Efetuar o Login de Cliente ou Funcionário, tendo em conta os requests a testar
- Contas exemplo:	
	-> Cliente:
		> user@gmail.com
		> password 
	-> Funcionário:
		> 1
		> admin
- Obter token de sessão do login
- Utilizar a token para fazer os respetivos requests